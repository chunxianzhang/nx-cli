//加载模块mysql
const mysql=require("mysql")
//创建对象
var pool=mysql.createPool({
      host:"w.rdc.sae.sina.com.cn",
      port:3306,
      user:"4wjloo3ko4",
      password:"xj2i42403iy5kh4il4m0x2m2hjzxlzz1mz13lwli",
      database:"app_nuoxin",
      connectionLimit:10
  })
  //导出对象
  module.exports=pool