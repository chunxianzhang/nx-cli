import Vue from 'vue'
import Router from 'vue-router'
import login from './components/login.vue'
import register from './components/register.vue'
import index from './components/index/index.vue'
import productCake from './components/product-cake/product-cake.vue'
import shoppingCar from './components/shopping-car/shopping-car.vue'
import productSearch from './components/product-search/product-search.vue'
import goods from './components/goods/goods.vue'



Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      component:index
    },
    {
      path:'/login',
      component:login
    },
    {
      path:'/register',
      component:register
    },
    {
      path:'/index',
      component:index
    },
    {
      path:'/product-cake',
      component:productCake
    },
    {
      path:'/shopping-car',
      component:shoppingCar
    },
    {
      path:'/product-search',
      component:productSearch
    },
    {
      path:'/goods',
      component:goods
    },
  ]
})
