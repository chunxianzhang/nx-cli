import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    isLogin:false,
    carCount:0,
  },
  mutations: {
    LOGININ(state){
      state.isLogin=true
    },
    LOGINOUT(state){
      state.isLogin=false
    },
    GETCARCOUNT(state,count){
      state.carCount=count
    },
    ADDCARCOUNT(state){
      state.carCount++
    },
    LESSENCARCOUNT(state){
      state.carCount--
    },
    DELETEALLCAKE(state){
      state.carCount=0
    }
  },
  getters:{
    getIsLogin:function(state){
      return state.isLogin
    },
    carCount:function(state){
      return state.carCount
    },
  }
})
