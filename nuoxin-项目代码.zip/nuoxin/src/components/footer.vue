<template>
  <div class="footer">
    <!--客服和微信-->
    <div class="footer_top">
      <a href="#" class="footer_top_left">在线客服</a>
      <a href="#" class="footer_top_right">微信
        <img src="http://nuoxin.applinzi.com/img/footer/wechat.png">
      </a>
    </div>
    <!--客户电话-->
    <div class="tel">
      <span>客服电话：4001-578-578 服务时间（08:30-22:30）</span>
    </div>
      <!-- nav列表 -->
    <div class="footer_nav">
      <p class="footer_nav_list">
        <a href="">诺心公告</a>
        <a href="">关于诺心</a>
        <a href="">联系我们</a>
        <a href="">客服服务</a>
        <a href="">食品经营许可证</a>
        <a href="">生产许可证</a>
        <a href="">预付费协议</a>
        <a href="" class="last">上海工商</a>
      </p>
    </div>
    <!-- 公司 -->
    <div class="add">
      <p>诺心食品（上海）有限公司&nbsp;&nbsp;&nbsp;上海徐汇区田林路140号28号楼503室&nbsp;&nbsp;客服邮箱：services@lecake.com&nbsp;&nbsp;公司电话：4001-578-578</p>
    </div>
    <!-- 版权所有 -->
    <div class="copy">
      <p>copyright&copy;2010-2017诺心lecake.com版权所有&nbsp;沪ICP备10211730</p>
    </div>
  </div>
</template>
<script>
import "@/assets/css/base.css"
import"@/assets/css/footer.css"
export default {
    
}
</script>
