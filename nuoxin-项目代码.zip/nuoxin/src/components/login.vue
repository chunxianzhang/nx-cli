<template>
  <div id="login">
    <div class="header">
        <router-link to="/">
            <img src="http://nuoxin.applinzi.com/img/header/logo_new.png">
        </router-link>
    </div>
    <div class="main">
        <router-link to="/login" class="reload"></router-link>
        <div class="login">
            <div class="login_method">
                <div class="login_one">
                    <span class="login_text_color" @click="login-upwd">账号密码登录</span>
                </div>
                <div class="login_two">
                    <span class="login_text" @click="login-smsCode">手机验证登录</span>
                </div>
            </div>
            <div class="login_item" @keyup.13="login">
                <!-- 账户密码登录 -->
                <div class="login_one_item">
                    <div class="login_uname">
                        <input type="text" class="login_uname_text" placeholder="请输入账号" v-model="uname" maxlength="11" @blur="unameJudge">
                        <span class="error_message" v-text="uname_message"></span>
                    </div>
                    <div class="login_upwd">
                        <input type="password" class="login_upwd_text" placeholder="请输入密码" v-model="upwd" maxlength="12" @blur="upwdJudge">
                        <span class="error_message" v-text="upwd_message"></span>
                    </div>
                    <div class="login_auth">
                        <input type="password" class="login_auth_code" placeholder="请输入验证码">
                        <a href="#" class="login_auth_code_hint"><img src="#" alt="点击刷新"></a>
                        <span class="error_message">*请输入验证码</span>
                    </div>
                </div>
                <!-- 手机验证登录 -->
                <div class="login_two_item">
                    <div class="login_phone">
                        <input type="text" class="login_phone_text" placeholder="手机号码">
                        <span class="error_message">*请输入手机号码</span>
                    </div>
                    <div class="login_auth">
                        <input type="password" class="login_auth_code" placeholder="请输入验证码">
                        <a href="#" class="login_auth_code_hint"><img src="#" alt="点击刷新"></a>
                        <span class="error_message">*请输入验证码</span>
                    </div>
                    <div class="login_sms">
                        <input type="password" class="login_sms_code" placeholder="短信验证码">
                        <span class="login_sms_code_hint">发送验证码</span>
                        <span class="error_message">*请输入短信验证码</span>
                    </div>
                </div>
                <button class="now_login" :class="active" @click="login">立即登录</button>
                <div class="account">
                    <a href="#" class="account_findUpwd">忘记密码</a>
                    <router-link to="/register" class="account_toRegister">立即注册</router-link>
                    <span class="account_null">还没有账号？</span>
                </div>
                <div class="other">
                    <div class="other_text">
                    <p>——————</P>
                    <P>其他登录方式</P>
                    <P>——————</p>
                    </div>
                    <a href="#" class="other_wechat"></a>
                </div>
            </div>
        </div>
    </div>
    <div v-cloak class="my_modal" v-show="modal">
        <div class="modal_bg"></div>
        <div class="modal_text">
            <h2>提示信息</h2>
            <p v-text="err_message"></p>
            <a href="#" class="yes" @click="close">确定</a>
            <a href="#" class="close" @click="close">X</a>
        </div>
    </div>
    <vueFooter></vueFooter>
  </div>
</template>
<script>
import "@/assets/css/login.css"
import "@/assets/css/base.css"
import "@/assets/css/footer.css"
import footer from '@/components/footer.vue'
export default {
    data:function(){
        return{
            uname:"",
            upwd:"",
            uname_message:"",
            upwd_message:"",
            modal:false,
            err_message:"",
            active:{"now_login_active":false},
        }
    },
    methods:{
        unameJudge(){
            var reg=/^1[3-8]\d{9}$/
            if(this.uname==""){
                this.uname_message="*请输入手机号";
                return false;
            }else if(!reg.test(this.uname)){
                this.uname_message="*手机号码格式错误";
                return false;
            }else{
                this.uname_message="";
                return true;
            }
        },
        upwdJudge(){
            if(this.upwd==""){
                this.upwd_message="*请输入密码";
                return false;
            }else{
                this.upwd_message="";
                return true;
            }
        },
        login(){
            if(this.unameJudge()&&this.upwdJudge()){
               this.active.now_login_active=true
               this.axios.post("user/login",
                    this.qs.stringify({
                        uname:this.uname,
                        upwd:this.upwd,
                    })
               )
               .then((res)=>{
                    var res=res.data;
                    if(res.ok==1){
                        if(location.search.startsWith("?back=")){
                            var back=location.search.slice(6)
                            back=decodeURIComponent(back)
                            if(back!==""){
                                this.$router.push(back)
                            }else{
                                this.$router.push("/")
                            }
                         }else{
                            this.$router.push("/")
                          }
                          setTimeout(()=>{
                            this.active.now_login_active=false;
                        },100)
                    }else{
                        if(res.upwd.length<6){
                            this.modal=true;
                            this.err_message="密码为6-12位非纯数字或字母"
                            setTimeout(()=>{
                                this.active.now_login_active=false;
                            },100)
                        }else{
                            this.modal=true;
                            this.err_message="密码错误"
                            setTimeout(()=>{
                                this.active.now_login_active=false;
                            },100)
                        }
                    }
               })
            }
        },
        close(){
            this.modal=false;
        },
    },
    components:{
        vueFooter:footer
    }
}
</script>
<style>
    [v-cloak]{display:none;}
</style>
