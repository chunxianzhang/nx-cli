<template>
  <div v-cloak v-show="loadF1" class="app-product">
      <div class="product">
        <!-- 上面两张 -->
        <div class="product_title">
          <a :href="proitem.skip_url" v-for="proitem in proTitle" :key="proitem.tid">
            <img :src="proitem.img_url">
          </a>
        </div>
        <!-- 下面八张 -->
        <div class="product_list">
          <div v-cloak class="product_detail"  v-for="listItem in proList" :key="listItem.id">
            <div class="product_detail_pic">
              <a :href="listItem.skip_url">
                <img :src="listItem.img_url">
              </a>
            </div>
            <a :href="listItem.skip_url" class="product_name" v-text="listItem.title"></a>
            <div class="product_tag">
              <span v-text="listItem.tag1" :class="listItem.tag1=='' ? 'hide':''"></span>
              <span v-text="listItem.tag2"  :class="listItem.tag2=='' ? 'hide':''"></span>
            </div>
            <div class="product_salary">
              <p v-text="listItem.price"></p>
              <p class="product_salary_vip" :class="listItem.price_vip=='' ? 'hide':''">
                <img src="http://nuoxin.applinzi.com/img/index/list/vip.png">
                <span v-text="listItem.price_vip"></span>
              </p>
            </div>
            <a href="#" class="product_shopping_car" @click.prevent="addCart(listItem.pid)">加入购物车+&nbsp;</a>
          </div>   
        </div>
        <div class="product_more"><a href="#">更多蛋糕 ></a></div>
      </div>
      <!-- F1模块 -->
      <div v-cloak v-show="loadF1" class="pub">
        <a href="#" class="pub_title" @click.prevent="navItemThree">
          <img src="http://nuoxin.applinzi.com/img/F1/F1_title.jpg">
        </a>
        <div class="pub_text">
          <div class="pub_product_list">
            <div v-cloak class="pub_product_detail" v-for="toastItem in toastList" :key="toastItem.id">
              <div class="pub_product_detail_pic">
                <a :href="toastItem.skip_url">
                  <img :src="toastItem.img_url">
                </a>
              </div>
              <a :href="toastItem.skip_url" class="pub_product_name" v-text="toastItem.title"></a>
              <div class="pub_product_tag">
                <span v-text="toastItem.tag1" :class="toastItem.tag1=='' ? 'hide':''"></span>
                <span v-text="toastItem.tag2" :class="toastItem.tag2=='' ? 'hide':''"></span>
              </div>
              <div class="pub_product_salary">
                <p v-text="toastItem.price"></p>
                <p class="pub_product_salary_vip" :class="toastItem.price_vip=='' ? 'hide':''">
                    <img src="http://nuoxin.applinzi.com/img/index/list/vip.png">
                    <span v-text="toastItem.price_vip"></span>
                </p>
              </div>
              <a href="#" class="pub_product_shopping_car" @click.prevent="ToastCart(toastItem.tid)">加入购物车+&nbsp;</a>
            </div>
          </div>
        </div>
        <div class="pub_product_more"><a href="#">更多吐司 ></a></div>
      </div>
      <!-- F2模块 -->
      <div v-cloak v-show="loadF2" class="pub">
        <a href="#" class="pub_title" @click.prevent="navItemFour">
          <img src="http://nuoxin.applinzi.com/img/F2/F2_title.jpg">
        </a>
        <div class="pub_text">
          <div class="pub_product_list">
            <div v-cloak class="pub_product_detail" v-for="giftItem in giftList" :key="giftItem.id">
              <div class="pub_product_detail_pic">
                <a :href="giftItem.skip_url">
                  <img :src="giftItem.img_url">
                </a>
              </div>
              <a :href="giftItem.skip_url" class="pub_product_name" v-text="giftItem.title"></a>
              <div class="pub_product_tag">
                <span v-text="giftItem.tag1" :class="giftItem.tag1=='' ? 'hide':''"></span>
                <span v-text="giftItem.tag2" :class="giftItem.tag2=='' ? 'hide':''"></span>
              </div>
              <div class="pub_product_salary">
                <p v-text="giftItem.price"></p>
                <p class="pub_product_salary_vip" :class="giftItem.price_vip=='' ? 'hide':''">
                    <img src="http://nuoxin.applinzi.com/img/index/list/vip.png">
                    <span v-text="giftItem.price_vip"></span>
                </p>
              </div>
              <a href="#" class="pub_product_shopping_car" @click.prevent="GiftCart(giftItem.gid)">加入购物车+&nbsp;</a>
            </div>
          </div>
        </div>
        <div class="pub_product_more"><a href="#">更多礼品 ></a></div>
      </div>
      <!-- 用户评论模块 -->
      <div v-cloak v-show="loadComment" class="user_comment">
        <h3>用户评论</h3>
        <div class="user_comment_text">
          <div class="user_comment_page1">
            <div class="user_comment_page">
              <div class="user_comment_header">
                <img src="http://nuoxin.applinzi.com/img/index/user/user_header1.png">
              </div>
              <div class="user_id">
                <p>134****2844</p>
              </div>
              <div class="user_comment_detail">
                <div class="user_comment_describe">
                  <p>口感一如既往的棒。流心有点甜,但是不影响整体的口感!</p>
                  <p>2018-09-27</p>
                </div>
                <div class="user_comment_product">
                  <a href="#"><img src="http://nuoxin.applinzi.com/img/index/user/user_comment1.png"></a>
                  <a href="#">立即购买</a>
                </div>
              </div>
            </div>
            <div class="user_comment_page">
              <div class="user_comment_header">
                <img src="http://nuoxin.applinzi.com/img/index/user/user_header2.png">
              </div>
              <div class="user_id">
                <p>134****2844</p>
              </div>
              <div class="user_comment_detail">
                <div class="user_comment_describe">
                  <p>好吃666666</p>
                  <p>2018-09-27</p>
                </div>
                <div class="user_comment_product">
                  <a href="#"><img src="http://nuoxin.applinzi.com/img/index/user/user_comment2.png"></a>
                  <a href="#">立即购买</a>
                </div>
              </div>
            </div>
            <div class="user_comment_page">
              <div class="user_comment_header">
                <img src="http://nuoxin.applinzi.com/img/index/user/user_header3.png">
              </div>
              <div class="user_id">
                <p>134****2844</p>
              </div>
              <div class="user_comment_detail">
                <div class="user_comment_describe">
                  <p>蛋糕非常不错，芝士味浓郁，不甜不腻，家人都喜欢的味道！</p>
                  <p>2018-09-27</p>
                </div>
                <div class="user_comment_product">
                  <a href="#"><img src="http://nuoxin.applinzi.com/img/index/user/user_comment3.png"></a>
                  <a href="#">立即购买</a>
                </div>
              </div>
            </div>
          </div>
          <div class="user_comment_page2">
            <div class="user_comment_page">
              <div class="user_comment_header">
                <img src="http://nuoxin.applinzi.com/img/index/user/user_header4.png">
              </div>
              <div class="user_id">
                <p>134****2844</p>
              </div>
              <div class="user_comment_detail">
                <div class="user_comment_describe">
                  <p>口感一如既往的棒。流心有点甜,但是不影响整体的口感!</p>
                  <p>2018-09-27</p>
                </div>
                <div class="user_comment_product">
                  <a href="#"><img src="http://nuoxin.applinzi.com/img/index/user/user_comment4.png"></a>
                  <a href="#">立即购买</a>
                </div>
              </div>
            </div>
            <div class="user_comment_page">
              <div class="user_comment_header">
                <img src="http://nuoxin.applinzi.com/img/index/user/user_header5.png">
              </div>
              <div class="user_id">
                <p>134****2844</p>
              </div>
              <div class="user_comment_detail">
                <div class="user_comment_describe">
                  <p>好吃666666</p>
                  <p>2018-09-27</p>
                </div>
                <div class="user_comment_product">
                  <a href="#"><img src="http://nuoxin.applinzi.com/img/index/user/user_comment5.png"></a>
                  <a href="#">立即购买</a>
                </div>
              </div>
            </div>
            <div class="user_comment_page">
              <div class="user_comment_header">
                <img src="http://nuoxin.applinzi.com/img/index/user/user_header_6.png">
              </div>
              <div class="user_id">
                <p>134****2844</p>
              </div>
              <div class="user_comment_detail">
                <div class="user_comment_describe">
                  <p>蛋糕非常不错，芝士味浓郁，不甜不腻，家人都喜欢的味道！</p>
                  <p>2018-09-27</p>
                </div>
                <div class="user_comment_product">
                  <a href="#"><img src="http://nuoxin.applinzi.com/img/index/user/user_comment6.png"></a>
                  <a href="#">立即购买</a>
                </div>
              </div>
            </div>
          </div>
          <a href="#" class="user_comment_prev"></a>
          <a href="#" class="user_comment_next"></a>
        </div>
      </div>
      <!-- 购物车模态框 -->
      <div v-cloak class="addCart_bg" v-show="cartBg"></div>
      <div v-cloak class="addCart" v-show="isaddcart">
        <div class="addCart_hint">
          <p>诺心蛋糕</p>
          <p @click="closeCart1">X</p>
        </div>
        <div class="addCart_text">
          <div class="addCart_title">
            <p v-text="carCake.title"></p>
            <p v-text="'￥'+carCake.price"></p>
          </div>
          <div>
            <table>
              <tr>
                <td>
                  <p  v-text="'口味：'+carCake.taste"></p>
                </td>
                <td>
                  <p v-text="carCake.spec"></p>
                </td>
                <td>
                  <p>含五套餐具</p>
                </td>
              </tr>
              <tr>
                <td>
                  <p v-text="'甜度：'+carCake.sweet"></p>
                </td>
                <td>
                  <p v-text="carCake.kg"></p>
                </td>
                <td></td>
              </tr>
            </table>
          </div>
          <div class="addCartNow">
            <button @click.prevent="goaddCart(carCake.id)">加入购物车</button>
          </div>
        </div>
      </div>
      <div v-cloak class="addCartSuccess" v-show="success">
          <div class="addCart_hint">
            <p>提示信息</p>
            <p @click="closeCart2">X</p>
          </div>
          <div class="cartMessage">
            <p>加入购物车成功</p>
          </div>
          <div class="cartSuccess">
            <button @click="account">去结算</button>
          </div>
      </div>
  </div>
</template>
<script>
import "@/assets/css/index.css"
export default {
    data:function(){
        return{
            //商品模块
            proTitle:[],
            proList:[],
            toastList:[],
            giftList:[],
            carCount:"",
            isaddcart:false,
            carCake:{title:"",price:"",taste:"",spec:"",sweet:"",kg:"",},
            cartBg:false,
            success:false,
            //加载
            loadF1:false,
            loadF2:false,
            loadComment:false,
        }
    },
    created(){
        this.getProTitle()
    },
    methods:{
       getProTitle(){
            this.axios.get("product/title")
            .then((res)=>{
                var res=res.data
                this.proTitle=res
                this.getProList()
            })
        },
        getProList(){
            this.axios.get("product/list")
            .then((res)=>{
                this.proList=res.data
                this.loadProduct=true;
                this.getToastList()
            })
        },
    //...吐司
        getToastList(){
            this.axios.get("product/toastList")
            .then((res)=>{
                this.toastList=res.data
                this.loadF1=true
                this.getGiftList() 
            })
        },
    //礼品
        getGiftList(){
            this.axios.get("product/giftList")
            .then((res)=>{
                this.giftList=res.data
                this.loadF2=true
                this.loadComment=true
            })
        },
    //加入购物车
        addCart(i){
            
            var id=i
            this.axios.get("product/proSpec?id="+id)
            .then((res)=>{
                var res=res.data
                if(res==-1){
                    alert("商品编号错误")
                }
                this.isaddcart=true
                this.cartBg=true
                this.carCake=res
            })
        },
        closeCart1(){
            this.isaddcart=false
            this.cartBg=false
        },
        goaddCart(i){
            var id=i
            this.axios.post("cart/addCar",this.qs.stringify({
                pid:id
            }))
            .then((res)=>{
                if(res.data.code==1){
                    this.isaddcart=false
                    this.success=true
                    this.$store.commit("ADDCARCOUNT")
                }else{
                    this.isaddcart=false
                    this.cartBg=false
                    alert("请先登录")
                    var url=location.search
                    this.$router.push("/login?back="+url)
                }
            })
        },
        closeCart2(){
            this.success=false
            this.cartBg=false
        },
        account(){
            this.success=false
            this.cartBg=false
            this.$router.push("/shopping-car")
        },
        ToastCart(i){
            if(this.isLogin==false){
                alert("请先登录")
                var url=location.search
                this.$router.push("/login?back="+url)
            }else{
                this.success=true
                this.cartBg=true  
            }
        },
        GiftCart(i){
            if(this.isLogin==false){
                alert("请先登录")
                var url=location.search
                this.$router.push("/login?back="+url)
            }else{
                this.success=true
                this.cartBg=true  
            }
        }      
    },
}
</script>
