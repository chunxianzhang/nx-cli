<template>
    <div class="app-carousel">
      <!-- 轮播图模块 -->
      <div class="banner">
        <div class="carousel">
          <!-- banner图片 -->
          <div class="carousel_inner">
            <div class="carousel_item" :style="'transform:translateX('+left+'px);transition-duration:'+time+'ms'">
              <a :href="item.skip_url" v-for="item in list" class="carousel_item_img" :key="item.id">
                <img :src="item.img_url">
              </a>
            </div>
          </div>
          <!-- left right 指示符 -->
          <a href="#" class="carousel_control_prev" @click.prevent="carouselPrev"  @mouseover="carouselOver" @mouseout="carouselOut"></a>
          <a href="#" class="carousel_control_next" @click.prevent="carouselNext"  @mouseover="carouselOver" @mouseout="carouselOut"></a>
        </div>  
      </div>
    </div>
</template>
<script>
import "@/assets/css/index.css"
export default {
    data:function(){
        return{
             //轮播模块
            list:[],
            left:0,
            nextLeft:0,
            time:0,
            transitionTime:1000,
            pno:0,
            intervalTime:6000,
            isHover:false,
        }
    },
    mounted(){
        this.getImg()
    },
    methods:{
        //轮播模块
         //获取轮播图片
        getImg(){
            this.axios.get("banner/getBannerImg")
            .then((res)=>{
                res=res.data
                res.push(res[0])
                var len=res.length
                res[len-1].banner_id=len
                this.list=res
                this.startCarousel(this.intervalTime) 
            })
        },
        //设置鼠标移到左右键时，轮播效果停止
        carouselOver(){
            this.isHover=true
        },
        carouselOut(){
            this.isHover=false
        },
        //设置轮播效果
        startCarousel(i){
            var len=this.list.length
            //窗口大小变动事件
            var width=document.body.clientWidth
            window.onresize=()=>{
                width=document.body.clientWidth
                    if(width<1200){return}
                    this.time=0
                    this.left=-width*this.pno
                    this.nextLeft=this.left
            }
            //轮播效果
            setInterval(()=>{
                if(document.visibilityState != 'hidden' && !this.isHover){
                    width=document.body.clientWidth
                    if(width<1200){width=1200}
                    this.time=this.transitionTime
                    this.nextLeft += -width
                    if(this.nextLeft==-(len)*width){
                        this.nextLeft=-width
                    }
                    this.left=this.nextLeft
                    setTimeout(()=>{
                        this.time=0
                    },this.time/2)
                    this.pno++
                    if(this.pno==6){
                        this.time=this.left=this.nextLeft=this.pno=0
                        setTimeout(()=>{
                            this.time=this.transitionTime
                            this.left=this.nextLeft=-width
                            this.pno=1
                        },100)
                    }
                }
            },i)
        },
        //上一个图片
        carouselPrev(){
            var len=this.list.length
            var width=document.body.clientWidth
            if(this.pno==0){
                this.time=0
                this.pno=len-1
                this.left=-width*(this.pno)
                this.nextLeft=this.left
                setTimeout(()=>{
                    this.time=this.transitionTime
                    this.carouselPrev()
                },100)
            }else{
                this.pno--
                this.time=this.transitionTime
                this.left=-width*(this.pno)
                this.nextLeft=this.left
            }
        },
        //下一个图片
        carouselNext(){
            var len=this.list.length
            var width=document.body.clientWidth
            if(this.pno==(len-1)){
                this.time=this.left=this.nextLeft=this.pno=0
                setTimeout(()=>{
                    this.time=this.transitionTime
                    this.left=this.nextLeft=-width
                    this.pno=1
                },100)
            }else{
                this.pno++
                this.time=this.transitionTime
                this.left=-width*(this.pno)
                this.nextLeft=this.left
            }
        },
    },
}
</script>

