<template>
 <div class="app-index">
    <div class="main">
        <v-header></v-header>
        <v-carousel></v-carousel>
        <v-products></v-products>
        <v-footer></v-footer>
    </div>
  </div>
</template>
<script>
import header from "@/components/header.vue"
import carousel from "@/components/index/carousel.vue"
import products from "@/components/index/products.vue"
import footer from "@/components/footer.vue"
export default {
    components:{
        "v-header":header,
        "v-carousel":carousel,
        "v-products":products,
        "v-footer":footer,
    }
}
</script>
