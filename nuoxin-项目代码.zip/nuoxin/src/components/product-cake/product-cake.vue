<template>
  <div class="app-cake">
    <v-header></v-header>
    <div class="main">
      <div class="cakeTitle">
        <table class="cakeSelect">
          <tr>
            <td>
                <span>口味：</span>
            </td>
            <td>
                <span :class="cakeSweet===1?'active':''" @click="AllTast">全部</span>
            </td>
            <td>
                <span :class="cakeSweet===2?'active':''" @click="NyTast">奶油口味</span>
            </td>
            <td>
                <span :class="cakeSweet===3?'active':''" @click="QklTast">巧克力口味</span>
            </td>
            <td>
                <span :class="cakeSweet===4?'active':''" @click="XgTast">鲜果口味</span>
            </td>
            <td>
                <span :class="cakeSweet===5?'active':''" @click="MsTast">莫斯口味</span>
            </td>
            <td>
                <span :class="cakeSweet===6?'active':''" @click="ZsTast">芝士口味</span>
            </td>            
          </tr>
          <tr>
            <td>
                <span>规格：</span>
            </td>
            <td>
                <span>全部</span>
            </td>
            <td>
                <span>2-4人食</span>
            </td>
            <td>
                <span>5-8人食</span>
            </td>
            <td>
                <span>10-12人食</span>
            </td>
            <td>
                <span>15-20人食</span>
            </td>
          </tr>
        </table>
      </div>
      <div class="cakeBody">
        <div v-cloak class="pub_product_detail" v-for="cakeItem in cakeList" :key="cakeItem.id">
          <div class="pub_product_detail_pic">
            <a :href="cakeItem.skip_url">
              <img :src="cakeItem.img_url">
            </a>
          </div>
          <div v-show="loadProText">
            <a :href="cakeItem.skip_url" class="pub_product_name" v-text="cakeItem.title"></a>
            <div class="pub_product_tag">
              <span v-text="cakeItem.tag1" :class="cakeItem.tag1=='' ? 'hide':''"></span>
              <span v-text="cakeItem.tag2" :class="cakeItem.tag2=='' ? 'hide':''"></span>
            </div>
            <div class="pub_product_salary">
              <p v-text="cakeItem.price"></p>
              <p class="pub_product_salary_vip" :class="cakeItem.price_vip=='' ? 'hide':''">
                <img src="http://nuoxin.applinzi.com/img/index/list/vip.png">
                <span v-text="cakeItem.price_vip"></span>
              </p>
            </div>
              <a href="#" class="pub_product_shopping_car" @click.prevent="cakeCart(cakeItem.pid)">加入购物车+&nbsp;</a>
          </div>
        </div>
      </div>
      <!-- 购物车模态框 -->
      <div v-cloak class="addCart_bg" v-show="cartBg"></div>
      <div v-cloak class="addCart" v-show="isaddcart">
        <div class="addCart_hint">
          <p>诺心蛋糕</p>
          <p @click="closeCart1">X</p>
        </div>
        <div class="addCart_text">
          <div class="addCart_title">
            <p v-text="carCake.title"></p>
            <p v-text="'￥'+carCake.price"></p>
          </div>
          <div>
            <table>
              <tr>
                <td>
                  <p  v-text="'口味：'+carCake.taste"></p>
                </td>
                <td>
                  <p v-text="carCake.spec"></p>
                </td>
                <td>
                  <p>含五套餐具</p>
                </td>
              </tr>
              <tr>
                <td>
                  <p v-text="'甜度：'+carCake.sweet"></p>
                </td>
                <td>
                  <p v-text="carCake.kg"></p>
                </td>
                <td></td>
              </tr>
            </table>
          </div>
          <div class="addCartNow">
            <button @click.prevent="goaddCart(carCake.id)">加入购物车</button>
          </div>
        </div>
      </div>
      <div v-cloak class="addCartSuccess" v-show="success">
          <div class="addCart_hint">
            <p>提示信息</p>
            <p @click="closeCart2">X</p>
          </div>
          <div class="cartMessage">
            <p>加入购物车成功</p>
          </div>
          <div class="cartSuccess">
            <button @click="account">去结算</button>
          </div>
      </div>
    </div>
    <v-footer></v-footer>
  </div>
</template>
<script>
import"@/assets/css/product-cake.css"
import header from "@/components/header.vue"
import footer from "@/components/footer.vue"
export default {
    data:function(){
        return {
            cakeList:[],
            cakeList2:[],
            isaddcart:false,
            carCake:{title:"",price:"",taste:"",spec:"",sweet:"",kg:"",},
            cakeSweet:1,
            cartBg:false,
            success:false,
            //加载
            loadProText:false,
        }
    },
    mounted(){
        this.getCakeList()
    },
    methods:{
        getCakeList(){
            this.axios.get("product/cakeList")
            .then((res)=>{
                this.cakeList=res.data
                this.cakeList2=res.data
                this.loadFooter=true
                setTimeout(()=>{ this.loadProText=true},100)
            })
        },
        //加入购物车
        cakeCart(i){
            var id=i
            this.axios.get("product/proSpec?id="+id)
            .then((res)=>{
                var res=res.data
                if(res==-1){
                    alert("商品编号错误")
                }
                this.isaddcart=true
                this.cartBg=true
                this.carCake=res
            })
        },
        closeCart1(){
            this.isaddcart=false
            this.cartBg=false
        },
        goaddCart(i){
            var id=i
            this.axios.post("cart/addCar",this.qs.stringify({
                pid:id
            }))
            .then((res)=>{
                if(res.data.code==1){
                    this.isaddcart=false
                    this.success=true
                    this.$store.commit("ADDCARCOUNT")
                }else{
                    this.isaddcart=false
                    this.cartBg=false
                    alert("请先登录")
                    var url=location.search
                    this.$router.push("/login?back="+url)
                }
            })
        },
        closeCart2(){
            this.success=false
            this.cartBg=false
        },
        account(){
            this.success=false
            this.cartBg=false
            this.$router.push("/shopping-car")
        },
        AllTast(){
            this.cakeList=this.cakeList2
            this.cakeSweet=1
        },
        NyTast(){
            var list=this.cakeList2
            var arr=[]
            for(var item of list){
                if(item.taste=="奶油口味"){
                    arr.push(item)
                }
            }
            this.cakeList=arr
            this.cakeSweet=2
        },
        QklTast(){
            var list=this.cakeList2
            var arr=[]
            for(var item of list){
                if(item.taste=="巧克力口味"){
                    arr.push(item)
                }
            }
            this.cakeList=arr
            this.cakeSweet=3
        },
        XgTast(){
            var list=this.cakeList2
            var arr=[]
            for(var item of list){
                if(item.taste=="鲜果口味"){
                    arr.push(item)
                }
            }
            this.cakeList=arr
            this.cakeSweet=4
        },
        MsTast(){
            var list=this.cakeList2
            var arr=[]
            for(var item of list){
                if(item.taste=="莫斯口味"){
                    arr.push(item)
                }
            }
            this.cakeList=arr
            this.cakeSweet=5
        },  
        ZsTast(){
            var list=this.cakeList2
            var arr=[]
            for(var item of list){
                if(item.taste=="芝士口味"){
                    arr.push(item)
                }
            }
            this.cakeList=arr
            this.cakeSweet=6
        },
    },
    components:{
        "v-header":header,
        "v-footer":footer,
    }
}
</script>
