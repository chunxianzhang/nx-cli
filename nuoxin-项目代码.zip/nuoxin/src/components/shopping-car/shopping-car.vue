<template>
    <div class="app-shoppingcar">
        <v-header></v-header>
        <div v-cloak class="shoppingCart">
            <h1 v-text="'您的购物车（'+this.$store.getters.carCount+'）'"></h1>
            <div :class="this.$store.getters.carCount==0?'':'hide'">
                <div class="no_count">
                    <img src="http://nuoxin.applinzi.com/img/product/no_count.png">
                </div>
                <p>您还没有选购商品，
                    <router-link to="/product-cake">去逛逛!</router-link>
                </p>
            </div>
            <div :class="this.$store.getters.carCount==0?'hide':''">
                <div class="userCake" v-for="item in userCake" :key="item.id">
                    <div class="checkCake">
                        <a href="#" class="isChecked" :class="item.isChecked==1?'checked':'nochecked'" @click.prevent="checked(item.goods_id)"></a>
                    </div>
                    <div class="cake_pic">
                        <a :href="item.skip_url">
                            <img :src="item.img_url">
                        </a>
                    </div>
                    <div class="userCake_details">
                        <p v-text="item.title"></p>
                        <p>2-4人食</p>
                        <p v-text="'单价：￥'+item.price"></p>
                        <p v-text="item.wishHint" :class="item.wishHint=='填写生日祝福'?'':'wish_active'" @click="showWishList(item.goods_id)" @mouseleave="hideWishList(item.goods_id)"></p>
                        <div v-cloak class="wish_list" :class="item.showWish==0?'hide':''" @mouseleave="hideWishList(item.goods_id)" @mouseenter="a(item.goods_id)">
                            <p v-text="wishList.one"  @click.prevent="getWish(item.goods_id,1)"></p>
                            <p v-text="wishList.two" @click.prevent="getWish(item.goods_id,2)"></p>
                            <p v-text="wishList.three" @click.prevent="getWish(item.goods_id,3)"></p>
                            <input type="text" placeholder="自定义" maxlength="16" v-model="item.userWish" @keyup.13.prevent="getWish(item.goods_id,4)">
                            <input type="button" value="确定" @click.prevent="getWish(item.goods_id,4)">
                            <p>(最多14个汉字或者28个英文字母)</p>
                        </div>
                    </div>
                    <div class="cakeTotal">
                        <p v-text="'小计：￥'+item.price*item.count"></p>
                        <div class="cake_count">
                            <a href="#" @click.prevent="lessenCount(item.goods_id)"></a>
                            <input type="text" :value="item.count">
                            <a href="#" @click.prevent="addCount(item.goods_id)"></a>
                        </div>
                    </div>
                </div>
                <div class="allTotal">
                    <div class="allTotalCheck">
                        <a href="#" class="isChecked" :class="isAllCheck==1?'checked':'nochecked'" @click.prevent="AllChecked"></a>
                        <p @click.prevent="AllChecked">全选</p>
                        <p @click.prevent="deleteAllGoods">删除</p>
                    </div>
                    <div class="allTotal_count">
                        <p>共 <span v-text="this.$store.getters.carCount"></span> 件商品，已选择 <span v-text="checkedCount"></span> 件</p>
                        <p>应付(不含运费)：￥<span class="allPrice" v-text="allPrice"></span></p>
                    </div>
                    <button>结算</button>
                </div>
            </div>
            <div class="accessories">
                <h1>精品配件</h1>
                <div class="acc_content">
                    <div class="acc_left" :class="accLeft==0?'disabled':''">
                        <a href="#" @click.prevent="accLeftShift"></a>
                    </div>
                    <div class="acc_group">
                        <ul class="acc_list" :style="'transform:translateX('+listLeft+'px)'">
                            <li v-for="item of accessoriesList" :key="item.id">
                                <div class="acc_item">
                                    <img :src="item.img_url">
                                    <p v-text="item.aname"></p>
                                    <p v-text="item.price"></p>
                                    <a href="#"></a>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="acc_right" :class="accright==0?'disabled':''">
                        <a href="#" @click="accRightShift"></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- 模态框 -->
        <div v-cloak class="addCart_bg" v-show="cartBg"></div>
        <div v-cloak class="addCartSuccess" v-show="success">
            <div class="addCart_hint">
                <p>提示信息</p>
                <p @click="closeCart2">X</p>
            </div>
            <div class="cartMessage">
                <p>确定删除？</p>
            </div>
            <div class="cartSuccess">
                <button @click="deleteGoods">确定</button>
                <button @click="closeCart2">取消</button>
            </div>
        </div>
        <v-footer></v-footer>
    </div>
</template>
<script>
import '@/assets/css/shopping-car.css'
import header from '@/components/header.vue'
import footer from '@/components/footer.vue'
export default {
    data:function(){
        return {
            userCake:[],
            wishList:{one:'不需要',two:'生日快乐',three:'Happy Birthday'},
            success:false,
            cartBg:false,
            deleteItem:0,
            isAllCheck:0,
            pno:0,
            goods_i:0,
            checkedCount:0,
            allPrice:0,
            accessoriesList:[],
            accLeft:0,
            accright:1,
            clickCount:0,
            listLeft:0,
        }
    },
    created(){
        this.getUserCake()
        this.getAccessories()
    },
    methods:{
        checked(i){
           for (var res of this.userCake){
               if(res.goods_id==i){
                   if(res.isChecked==1){
                        res.isChecked=0
                        this.checkedCount-=res.count
                        this.allPrice-=res.count*res.price
                        this.axios.get("cart/updateCheck?check="+res.isChecked+"&goods_id="+res.goods_id)
                        this.isAllCheck=0
                   }else{
                        res.isChecked=1
                        this.pno=0
                        this.checkedCount+=res.count
                        this.allPrice+=res.count*res.price
                        this.axios.get("cart/updateCheck?check="+res.isChecked+"&goods_id="+res.goods_id)
                        for(var item of this.userCake){
                            if(item.isChecked==0){
                                this.pno=1
                            }
                        }
                        if(this.pno==0){
                            this.isAllCheck=1
                        }
                   }
               }
           }
        },
        getUserCake(){
            window.scrollTo(0,0)
            this.axios("cart/userCake")
            .then((res)=>{
                if(res.data.code==-1)return
                this.pno=0
                this.userCake=res.data
                for(var item of this.userCake){
                    if(item.wishHint==null){
                        item.wishHint="填写生日祝福"
                    }
                    if(item.isChecked==0){
                        this.pno=1
                    }
                    if(item.isChecked==1){
                        this.checkedCount+=item.count
                        this.allPrice+=item.count*item.price
                    }
                }
                if(this.pno==0){
                    this.isAllCheck=1
                }
            })
        },
        getWish(i,j){
            for(var item of this.userCake){
                if(item.goods_id==i){
                    if(j==1){
                        item.wishHint=this.wishList.one
                        item.showWish=0
                    }else if(j==2){
                        item.wishHint=this.wishList.two
                        item.showWish=0
                    }else if(j==3){
                        item.wishHint=this.wishList.three
                        item.showWish=0
                    }else{
                        item.wishHint=item.userWish
                        item.showWish=0
                    }
                }
            }
        },
        showWishList(i){
            for(var item of this.userCake){
                if(item.goods_id==i){
                    item.showWish=1
                }
            }
        },
        a(i){
            for(var item of this.userCake){
                if(item.goods_id==i){
                    item.showWish=1
                }
            }
        },
        hideWishList(i){
            for(var item of this.userCake){
                if(item.goods_id==i){
                    item.showWish=0
                }
            }
        },
        addCount(i){
            for(var item of this.userCake){
                if(item.goods_id==i){
                    item.count++
                    this.allPrice+=item.price
                    this.$store.commit("ADDCARCOUNT")
                    this.checkedCount++
                    this.axios.get("cart/updateCount?count="+item.count+"&goods_id="+item.goods_id)
                }
            }
        },
        lessenCount(i){
            for(var item of this.userCake){
                if(item.goods_id==i){
                    if(item.count==1){
                        this.success=true
                        this.cartBg=true
                        this.deleteItem=i
                    }else{
                        item.count--
                        this.allPrice-=item.price
                        this.$store.commit("LESSENCARCOUNT")
                        this.checkedCount--
                        this.axios.get("cart/updateCount?count="+item.count+"&goods_id="+item.goods_id)
                    }
                }
            }
        },
        closeCart2(){
            this.success=false
            this.cartBg=false
        },
        deleteGoods(){
            var j=this.deleteItem
            if(j!="all"){
                for(var i=0,len=this.userCake.length;i<len;i++){
                    if(this.userCake[i].goods_id==j){
                        this.goods_i=i
                        this.allPrice-=this.userCake[i].price
                        this.$store.commit("LESSENCARCOUNT")
                        this.checkedCount--
                        this.axios.get("cart/deleteGoods?goods_id="+j)
                        .then((res)=>{
                            if(res.data.code==1){
                                this.userCake.splice(this.goods_i,1)
                                i--
                                len--
                                this.success=false
                                this.cartBg=false
                            }
                        })
                    }
                }
            }else{
                this.axios.get("cart/deleteAllGoods")
                .then((res)=>{
                    if(res.data.code==1)
                    this.$store.commit("DELETEALLCAKE")
                    this.checkedCount=0
                    this.success=false
                    this.cartBg=false
                })
            }
        },
        AllChecked(){
            if(this.isAllCheck==0){
                this.axios.get("cart/allChecked")
                .then((res)=>{
                    if(res.data.code==1){
                        this.checkedCount=0
                        this.allPrice=0
                        for(var item of this.userCake){
                            item.isChecked=1
                            this.checkedCount+=item.count
                            this.allPrice+=item.count*item.price
                        }
                        this.isAllCheck=1
                    }
                })
            }else{
                this.axios.get("cart/allNoChecked")
                .then((res)=>{
                    if(res.data.code==1){
                        for(var item of this.userCake){
                            item.isChecked=0
                        }
                        this.isAllCheck=0
                        this.checkedCount=0
                        this.allPrice=0
                    }
                })
            }
        },
        deleteAllGoods(){
            this.deleteItem="all"
            this.success=true
            this.cartBg=true
        },
        getAccessories(){
            this.axios("cart/getAccessories")
            .then((res)=>{
                this.accessoriesList=res.data
            })
        },
        accLeftShift(){
            if(this.listLeft<0){
                this.clickCount++
                this.listLeft=this.clickCount*925
                this.accright=1
                if(this.listLeft==0)
                this.accLeft=0
            }
        },
        accRightShift(){
            if(this.listLeft>-2775){
                this.accLeft=1
                this.clickCount--
                this.listLeft=this.clickCount*925
                if(this.listLeft==-2775)
                this.accright=0
            }
        },
    },
    components:{
        'v-header':header,
        'v-footer':footer
    }
}
</script>
