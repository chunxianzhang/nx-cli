<template>
  <div id="register">
    <div class="my_header">
        <div class="my_header_logo">
            <span>&nbsp;&nbsp;用户注册</span>
            <router-link to="/">
                <img src="http://nuoxin.applinzi.com/img/header/logo_new.png" alt="">
            </router-link>
        </div>
        <div class="my_header_login">
            <span>已有诺心账号?&nbsp;</span>
            <router-link to="login">请登录</router-link>
        </div>
    </div>
    <div class="main">
        <div class="register">
            <div class="input_phone">
                <input type="text" placeholder="手机号码" maxlength="11" class="input_phone_text" v-model="phone" @blur="phoneJudge">
                <span class="error_message" v-text="phone_message"></span>
            </div>
            <div class="input_pwd">
                <input type="password" placeholder="6-12位密码" maxlength="12" class="input_pwd_text" v-model="upwd" @blur="upwdJudge">
                <span class="error_message" v-text="upwd_message"></span>
            </div>
            <div class="input_pwd_again">
                <input type="password" placeholder="确认密码" maxlength="12" class="input_pwd_again_text" v-model="upwdAgain" @blur="upwdAgainJudge">
                <span class="error_message" v-text="upwdAgain_message"></span>
            </div>
            <div class="sliding_block" >
                <div class="sliding_block_bg" v-text="bg_text"></div>
                <div :class="btn_bg" @mousedown="slideJudgeDown"  :style="'left:'+left+';transition:'+transition"></div>
                <div class="btn_before_bg" :style="'width:'+bg_width+';transition:'+transition" v-text="bg_success_text"></div>
                <div class="bg_animation" v-show="is_animate"></div>
            </div>
            <div class="sliding_block_err">
                <span class="error_message" v-text="slide_message"></span>
            </div>
            <div class="auth_code">
                <input type="text" placeholder="手机验证码" class="auth_code_input">
                <a href="#" class="auth_code_hint">发送验证码</a>
                <span class="error_message" v-text="code_message"></span>
            </div>
            <button class="register_now" @click="register">立即注册</button>
            <div class="read_agreement">
                <label for="agree" ><input type="checkbox" id="agree" v-model="isChecked" @click="isRead">&nbsp;我已阅读并同意</label>
                <a href="#" class="read_agreement_text">《诺心lecake用户服务协议》</a>
                <span class=error_message v-text="agreement_message"></span>
            </div>
        </div>
    </div>
    <vueFooter></vueFooter>   
  </div>
</template>
<script>
import "@/assets/css/base.css"
import "@/assets/css/register.css"
import footer from "@/components/footer.vue"
export default {
    data:function(){
        return{
            phone:"",
            upwd:"",
            upwdAgain:"",
            bg_text:"请按住滑块，拖动到最右边",
            bg_success_text:"",
            left:"0",
            bg_width:"0",
            transition:"",
            btn_bg:{
                sliding_block_btn:true,
                siliding_block_success_bg:false,
            },
            is_animate:true,
            is_success:false,
            phone_message:"",
            upwd_message:"",
            upwdAgain_message:"",
            slide_message:"",
            code_message:"",
            agreement_message:"",
            isChecked:true,
        }
    },
    methods:{
        phoneJudge(){
            var reg=/^1[3-8]\d{9}$/
            if(this.phone==""){
                this.phone_message="*请输入手机号码";
                return false;
            }else if(!reg.test(this.phone)){
                this.phone_message="*手机号码格式错误";
                return false;
            }else{
                this.phone_message="";
                return true;
            }
        },
        upwdJudge(){
            var reg=/\d/
            if(this.upwd==""){
                this.upwd_message="*请输入密码";
                return false;
            }else if(Number(this.upwd) || !reg.test(this.upwd) || this.upwd.length<6){
                this.upwd_message="*密码为6-12位的非纯数字";
                return false;
            }else{
                this.upwd_message="";
                if(this.upwdAgain!=""){
                    this.upwdAgainJudge();
                }
                return true;
            }
        },
        upwdAgainJudge(){
            if(this.upwd!=""){
                if(this.upwdAgain==""){
                    this.upwdAgain_message="*请输入密码";
                    return false;
                }else if(this.upwd!=this.upwdAgain){
                    this.upwdAgain_message="*两次输入的密码不一致";
                    return false;
                }else{
                    this.upwdAgain_message="";
                    return true;
                }
            }else{
                return false;
            }
        },
        slideJudgeDown(e){
            e=event;
            var Mx=209;
            this.transition="";
            var startX=e.clientX;
            var success=false;
            document.onmousemove=(e)=>{
                e=event;
                var endX=e.clientX;
                var X=endX-startX;
                if(X>Mx){
                    X=Mx;
                    this.btn_bg.sliding_block_btn=false;
                    this.btn_bg.siliding_block_success_bg=true;
                    this.bg_text="";
                    this.bg_success_text="验证成功";
                    this.is_animate=false;
                    this.is_success=true;
                    document.onmousemove=null;
                    this.slideJudgeDown=()=>{return};
                }else if(X<0){
                    X=0;
                }
                this.left=X+"px";
                this.bg_width=X+"px";
            }
            document.onmouseup=(e)=>{
                document.onmousemove=null;
                if(this.is_success){
                   return; 
                }else{
                    this.left=0;
                    this.bg_width=0;
                    this.transition=".5s ease"
                }
                document.onmouseup=null;
            }
        },
        isRead(){
            if(this.isChecked==true){
                this.isChecked=false;
                this.agreement_message="*用户协议未勾选";
                return false;
            }else{
                this.isChecked=true;
                this.agreement_message="";
                return true;
            }
        },
        register(){
            if(this.phoneJudge()&&this.upwdJudge()&&this.upwdAgainJudge()){
            console.log(0)
                if(this.is_success==false){
                    this.slide_message="*请滑动滑块进行验证"
                } else if(this.isChecked==false){
                    this.slide_message=""
                    this.agreement_message="*用户协议未勾选";
                }else{
                    this.slide_message="";
                    this.agreement_message="";
                    this.axios.post("user/register",
                        this.qs.stringify({
                            uname:this.phone,
                            upwd:this.upwd,
                        })
                    )
                    .then((res)=>{
                        var res=res.data;
                        if(res==0){
                            alert("用户名已经存在")
                        }else if(res==1){
                            alert("注册成功")
                            setTimeout(()=>{
                                this.$router.push('/login')
                            },1000)
                        }else{
                            alert("注册失败，请稍后再试")
                        } 
                    })
                }
            }
        },
    },
    components:{
        vueFooter:footer
    }
}
</script>

