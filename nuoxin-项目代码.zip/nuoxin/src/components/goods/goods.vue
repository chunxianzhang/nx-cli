<template>
    <div class="app-goods">
        <v-header></v-header>
        <div class="main">
            <div class="goodsTitle">
                <img :src="goodsList.title_url">
            </div>
            <div v-cloak class="goods_detail" v-show="loadDetail">
                <div class="detail_title">
                    <div class="detail_name">
                        <span v-text="goodsList.gname"></span>
                        <span v-text="'￥'+goodsList.price"></span>
                    </div>
                    <div class="promotion">
                        <p v-text="promotion.title"></p>
                        <p v-text="promotion.p1"></p>
                        <p v-text="promotion.p2"></p>
                        <p v-text="promotion.p3"></p>
                    </div>
                </div>
                <div class="detail_text">
                    <p>建议食用人数</p>
                    <ul class="detail_tex">
                        <li :class="texone">
                            <span @click="texActive(1)">2-4人食</span>
                        </li>
                        <li :class="textwo">
                            <span @click="texActive(2)">5-8人食</span>
                        </li>
                        <li :class="texthree">
                            <span @click="texActive(3)">10-12人食</span>
                        </li>
                        <li :class="texfour">
                            <span @click="texActive(4)">15-20人食</span>
                        </li>
                    </ul>
                    <ul class="detail_spec">
                        <li>含五套餐具</li>
                        <li v-text="goodsList.spec"></li>
                        <li v-text="goodsList.kg"></li>
                        <li v-text="'甜度：'+goodsList.sweet"></li>
                    </ul>
                    <div class="addCart">
                        <button @click="addCart(goodsList.id)">加入购物车+</button>
                        <button @click="buyNow(goodsList.id)">立即购买</button>
                    </div>
                </div>
            </div>
            <div class="describe">
                <div class="subtitle_pic">
                    <img :src="goodsList.subtitle_url">
                    <img :src="goodsList.t1_url">
                </div>
            </div>
            <div v-cloak class="addCart_bg" v-show="cartBg"></div>
            <div v-cloak class="addCartSuccess" v-show="success">
                <div class="addCart_hint">
                    <p>提示信息</p>
                    <p @click="closeCart2">X</p>
                </div>
                <div class="cartMessage">
                    <p>加入购物车成功</p>
                </div>
                <div class="cartSuccess">
                    <button @click="account">去结算</button>
                </div>
            </div>
            <div v-cloak v-show="loadMaterials">
            <div class="materials">
                <p>主要原材料</p>
                <p>Main raw materials</p>
                <p>—————</p>
                <div class="food_materials">
                    <ul>
                        <li>
                            <span>食材配比</span>
                        </li>
                        <li>
                            <span>巧克力</span>
                        </li>
                        <li>
                            <span>淡奶油</span>
                        </li>
                        <li>
                            <span>黄油</span>
                        </li>
                        <li>
                            <span>幼砂糖</span>
                        </li>
                    </ul>
                    <ul>
                        <li>
                            <span>产地</span>
                        </li>
                        <li>
                            <span>比利时</span>
                        </li>
                        <li>
                            <span>新西兰</span>
                        </li>
                        <li>
                            <span>中国</span>
                        </li>
                        <li>
                            <span>韩国</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="remind">
                <div class="remind_left">
                    <p>如何定制个性语音</p>
                    <p>DIY radio</p>
                   <img src="http://nuoxin.applinzi.com/img/product/goods-1/audio.jpg"><br>
                   <img src="http://nuoxin.applinzi.com/img/product/goods-1/wave.jpg">
                   <div class="reimnd_ltext">
                        <p>1 成功提交订单后，添加录音</p>
                        <p>2 添加录音（时长限制21秒）</p>
                        <p>3 录制成功后，上传即可</p>
                        <p>4 收货人收到蛋糕后，微信扫描卡片上的二维码，即可倾听ta的心声</p>
                    </div>
                </div>
                <div class="remind_right">
                    <p>关于食用</p>
                    <p>About edible</p>
                    <img src="http://nuoxin.applinzi.com/img/product/goods-1/fork.jpg">
                    <div class="reimnd_rtext">
                        <p>适合人群：大众</p>
                        <p>适合季节：所有</p>
                        <p>保鲜条件：冷藏0~4摄氏度</p>
                        <p>食用方法：请收到蛋糕后2-3小时内食用</p>
                        <p>温馨提示：本产品使用了蒸馏酒进行调味。</p>
                        <p>*商品以实物为准。</p>
                    </div>
                </div>
            </div>
            <div class="recommend">
                <p>热门推荐</p>
            </div>
            <div class="cake">
                <div v-cloak class="pub_product_detail" v-for="cakeItem in cakeList" :key="cakeItem.id">
                    <div class="pub_product_detail_pic">
                        <a :href="cakeItem.skip_url">
                        <img :src="cakeItem.img_url">
                        </a>
                    </div>
                    <div>
                        <a :href="cakeItem.skip_url" class="pub_product_name" v-text="cakeItem.title"></a>
                        <div class="pub_product_tag">
                        <span v-text="cakeItem.tag1" :class="cakeItem.tag1=='' ? 'hide':''"></span>
                        <span v-text="cakeItem.tag2" :class="cakeItem.tag2=='' ? 'hide':''"></span>
                        </div>
                        <div class="pub_product_salary">
                        <p v-text="cakeItem.price"></p>
                        <p class="pub_product_salary_vip" :class="cakeItem.price_vip=='' ? 'hide':''">
                            <img src="http://nuoxin.applinzi.com/img/index/list/vip.png">
                            <span v-text="cakeItem.price_vip"></span>
                        </p>
                        </div>
                        <a :href="cakeItem.skip_url" class="pub_opend_etail">查看详情&nbsp;>></a>
                    </div>
                </div>
            </div>
            </div>
        </div>
        <v-footer></v-footer>
    </div>
</template>
<script>
import '@/assets/css/goods.css'
import header from "@/components/header.vue"
import footer from "@/components/footer.vue"
export default {
    data:function(){
        return {
            cartBg:false,
            success:false,
            goodsList:[],
            cakeList:[],
            carCount:"",
            promotion:{title:"优惠促销",p1:"【玩转舌尖 纵享魔力】2018.9.30-2018.11.8下单且不晚于11.9配送的蛋糕订单，每单可9.9元加价购「哇哦！吐司」1份，先到先得，不与其他优惠同享。",p2:"【狂欢派对 甜蜜加倍】2018.11.1-2018.11.25，正价购买蛋糕馆内任意蛋糕，每笔订单赠半价蛋糕券1张（订单配送完成后48小时内到账）。配送时间截至2018.11.26。",p3:"【生日专“数” 缤纷好礼】2018.11.1-2018.11.29，正价购买指定款蛋糕1个，加18元即享加大升级。2-4人食蛋糕加大为5-8人食，5-8人食蛋糕加大为10-12人食。（适用蛋糕仅限5-8人食及以下规格）。配送时间：2018.11.2-2018.11.30。"},
            texone:{tex_active:true},
            textwo:{tex_active:false},
            texthree:{tex_active:false},
            texfour:{tex_active:false},
            loadDetail:false,
            loadMaterials:false,
        }
    },
    created(){
        this.getGoodsList()
        this.getRecommendList()
    },
     methods:{
        getGoodsList(){
            var str=location.search
            str = str.replace(/\s*/g,"");
            this.axios.get("goods/goodsList"+str)
            .then((res)=>{
                this.goodsList=res.data
                this.loadDetail=true
                this.loadMaterials=true
            })
        },
        texActive(i){
            if(i==1){
                this.texone.tex_active=true
                this.textwo.tex_active=this.texthree.tex_active=this.texfour.tex_active=false
            }else if(i==2){
                this.textwo.tex_active=true
                this.texone.tex_active=this.texthree.tex_active=this.texfour.tex_active=false
            }else if(i==3){
                this.texthree.tex_active=true
                this.textwo.tex_active=this.texone.tex_active=this.texfour.tex_active=false
            }else if(i==4){
                this.texfour.tex_active=true
                this.textwo.tex_active=this.texthree.tex_active=this.texone.tex_active=false
            }
        },
        addCart(i){
            var id=i
            this.axios.post("cart/addCar",this.qs.stringify({
                pid:id
            }))
            .then((res)=>{
                if(res.data.code==1){
                    this.cartBg=true
                    this.success=true
                    this.$store.commit("ADDCARCOUNT")
                }else{
                    this.success=false
                    this.cartBg=false
                    alert("请先登录")
                    var url=location.search
                    this.$router.push("/login?back="+url)
                }
            })
        },
        closeCart2(){
            this.success=false
            this.cartBg=false
        },
        account(){
            this.success=false
            this.cartBg=false
            this.$router.push("/shopping-car")
        },
        buyNow(i){
            var id=i
            this.axios.post("cart/addCar",this.qs.stringify({
                pid:id
            }))
            .then((res)=>{
                if(res.data.code==1){
                    this.$router.push("/shopping-car")
                }else{
                    alert("请先登录")
                    var url=location.search
                    this.$router.push("/login?back="+url)
                }
            })
        },
        getRecommendList(){
            this.axios.get("goods/recommendList")
            .then((res)=>{
                this.cakeList=res.data
                this.loadFooter=true
            })
        }
    },
    components:{
        "v-header":header,
        "v-footer":footer,
    }
}
</script>
