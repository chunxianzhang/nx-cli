<template>
    <div class="header">
      <!--登录/注册-->
      <div class=header_top>
        <div class=header_top_right>
          <div v-if="signout" class="notLogin">
            <a href="#" @click.prevent="goLogin">登录</a>
            <span> / </span>
            <router-link to="/register">注册</router-link>
          </div>
          <div v-if="isLogin" class="isLogin">
            <span>欢迎您，</span>
            <span v-text="uname"></span>
            <a href="#" class="signout" @click.prevent="signOut">退出</a>
            <a href="#" @click.prevent="myIndent">我的订单</a>
          </div>
          <p class="header_top_wechat">
            <img src="http://nuoxin.applinzi.com/img/header/wechat.png" class="top_wechat_img">
            微信
          </p>
        </div>
      </div>
      <!--定位和logo-->
      <div class="header_middle">
        <div class="header_location">
          <a href="#" class="location">
            <span class="one">成都</span>
            <span class="two">查询地址是否可以配送</span>
          </a>
        </div>
        <div class="header_logo">
          <img src="http://nuoxin.applinzi.com/img/header/logo_new.png">
        </div>
        <div class="header_search">
          <input type="text" placeholder="雪域牛乳芝士" class="header_search_input" v-model="search_text" @keyup.13="search">
          <a href="#" class="one" @click.prevent="search"></a>
          <a href="#" class="two" @click.prevent="shoppingCart">
            <span :class="this.$store.getters.carCount==0?'hide':'showCount'" v-text="this.$store.getters.carCount"></span>
          </a>
        </div>
      </div>
      <!--nav-->
      <nav>
        <ul class="nav_list">
          <li>
            <a href="#" class="nav_list_first" :class="nav_active_pno==1?'nav_active':''" @click.prevent="navItemOne">首页</a>
          </li>
          <li>
            <a href="#" class="nav_list_two" :class="nav_active_pno==2?'nav_active':''" @click.prevent="navItemTwo">蛋糕</a>
          </li>
          <li>
            <a href="#" class="nav_list_three" @click.prevent="navItemThree">吐司</a>
          </li>
          <li>
            <a href="#" class="nav_list_four" @click.prevent="navItemFour">礼品</a>
          </li>
          <li>
            <div class="nav_area">
              <a href="#">企业专区</a>
              <ul class="nav_area_list">
                <li><a href="#">企业采购</a></li>
                <li><a href="#">大客户区</a></li>
                <li><a href="#">福利券区</a></li>
                <li><a href="#">合作专区</a></li>
                <li><a href="#">小食盒区</a></li>
             </ul>
            </div>
          </li>
          <li>
            <div class="nav_user">
              <a href="#" @click.prevent="navItemFive">我的诺心</a>
              <ul class="nav_user_list">
                <li><a href="#" @click.prevent="CLUB">LECLUB</a></li>
                <li><a href="#" @click.prevent="myIndent">我的订单</a></li>
                <li><a href="#">找回密码</a></li>
                <li><a href="#" @click.prevent="card">礼卡专区</a></li>
             </ul>
            </div>
          </li>
        </ul>
      </nav>
    </div>
</template>
<script>
import "@/assets/css/header.css"
import "@/assets/css/base.css"
export default {
    data:function(){
        return {
           signout:true,
           isLogin:false,
           uname:"",
           search_text:"",
           nav_active_pno:0,
        }
    },
    created(){
        this.getIsLogin()
        this.getSearchText()
        this.getNavActive()
    },
    methods:{
        getIsLogin(){
            this.axios.get("user/islogin")
            .then((res)=>{
                var res=res.data
                if(res.ok==0){
                    this.signout=true
                    this.isLogin=false
                }else{
                    this.signout=false
                    this.isLogin=true
                    this.uname=res.uname
                    this.$store.commit("LOGININ")
                    this.getCarCount()
                }
            })
        },
        goLogin(){
            var url=location.href
            var i=url.indexOf('/',7)
            url=url.slice(i+1)
            this.$router.push("/login?back="+url)
        },
        signOut(){
            this.axios.get("user/signout")
            .then((res)=>{
                location.reload(true)
            })
        },
        myIndent(){
            if(this.isLogin==true){
                this.$router.push("/")
            }else{
                this.$router.push("/")
            }
        },
        search(){
            var str=this.search_text
            str = str.replace(/\s*/g,"");
            if(str=="")
            str="雪域"
            var url=location.href
            if(url.indexOf("product-search")!=-1){
                this.$router.push("/product-search?kw="+str)
                location.reload()
            }else{
                this.$router.push("/product-search?kw="+str)
                 this.search_text=str
            }
        },
        getSearchText(){ 
            var url=location.href
            if(url.indexOf("product-search")!=-1){
                location.search.startsWith("?kw=")
                var kw=location.search.slice(4)
                kw=decodeURIComponent(kw)
                this.search_text=kw
            }
        },
        shoppingCart(){
            if(this.isLogin==true){
                this.$router.push("/shopping-car")
            }else{
                alert("请先登录")
                var url=location.search
                this.$router.push("/login?back="+url)
            }
        },
        getCarCount(){
                if(this.isLogin){
                    this.axios.get("cart/getCount")
                    .then((res)=>{
                        var count=res.data[0].count
                        this.$store.commit("GETCARCOUNT",count)
                    })
                }else{
                    this.$store.commit("DELETECAKE")
                }    
        },
        getNavActive(){
             var url=location.href
            if(url.slice(-1)=="/"||url.indexOf("0/index")!=-1){
               this.nav_active_pno=1
            }else if(url.indexOf("/product-cake")!=-1){
               this.nav_active_pno=2
            }else{
               this.nav_active_pno=0
            }
        },
        navItemOne(){
            this.$router.push("/")
        },
        navItemTwo(){
            this.$router.push("/product-cake")
        },
        navItemThree(){
            this.$router.push("/product-toast")
        },
        navItemFour(){
            this.$router.push("/product-gift")
        },
        navItemFive(){
            this.$router.push("/user")
        },
        CLUB(){},
        card(){},
    },
}
</script>
